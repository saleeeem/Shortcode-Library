<?php

register_block_type(
    'shortcode-directory/shortcode-block-list', array(
      'render_callback' => 'event_block'
    )
  );



  function event_block($attributes) {

   if($attributes['catSelect']){
    $block_cat = esc_html( $attributes['catSelect'] );
   }

   $block_cat = trim($block_cat);

   //var_dump($block_cat);

    $output .="<div class='shortcode-directory ".$block_view."'>";
    $output .= do_shortcode("[$block_cat]");
    $output .="</div>";


 return $output ;


  } 

  // Register Rest api key endpoints

  function shortcode_data(){
  
           global $wpdb;
           $table_name = $wpdb->prefix . 'shortcode_directory_table';
            $result = $wpdb->get_results( "SELECT * FROM $table_name");

            $data = [];
            $i = 0;
            foreach ( $result as $print )   { 
                      
                        $data[$i]['id'] = $print->id;
                        $data[$i]['name'] =  $print->name;
                        $data[$i]['shortcode_name'] =  $print->shortcode;

                        $i++;
                 }

          return $data;
  }
  
  add_action( 'rest_api_init', 'my_rest_api_init', 10, 1 );
  function my_rest_api_init() {
      register_rest_route( 'shortcode-directory/v1', '/shortcodes', array(
          'methods'             => 'GET',
         // 'permission_callback' => '__return_true', // *always set a permission callback
          'callback'            => 'shortcode_data',
      ) );
  }