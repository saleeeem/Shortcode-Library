<table border="0">
    <tr>
     <th>id</th>
     <th>name</th>
     <th>Shortcode</th>
    </tr>

      <?php

        $result = $wpdb->get_results( "SELECT * FROM $table_name");
        foreach ( $result as $print )   { ?>
          <tr>
                  <td >  <?php echo $print->id; ?> </td>
                  <td><?php echo $print->name; ?> </td>
                  <td><?php echo $print->shortcode; ?> </td>
                  <td><button id="<?php echo $print->id; ?>" class="shortcode-delete">Delete</button> </td>
          </tr>
            <?php }
      ?>

</table>