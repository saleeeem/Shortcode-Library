//  Import CSS.
import '../editor.css';
import '../style.css';

const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks
const { InspectorControls, RichText, InnerBlocks } = wp.editor;
const { ToggleControl, PanelBody, PanelRow, CheckboxControl, SelectControl, ColorPicker  } = wp.components;
const { Fragment , useState } = wp.element;



 const postSelections = [];

 const allPosts = wp.apiFetch({path: "/shortcode-directory/v1/shortcodes"}).then( id => {
	 postSelections.push({label: "Select a Shortcode", value: 0});
	 jQuery.each( id, function( key, val ) {
		 postSelections.push({label: val.name, value: val.shortcode_name});
	 });
	 return postSelections;
 });


// function showCustomer() {
	
// 	const xhttp = new XMLHttpRequest();
// 	xhttp.open("GET", "shortcode_data.php");
// 	xhttp.onload = function() {
// 	  var response = this.responseText;

// 	  console.log(response);
// 	}
	
// 	xhttp.send();
//   }



registerBlockType( 'shortcode-directory/shortcode-block-list', {
	// Block name. Block names must be string that contains a namespace prefix. Example: my-plugin/my-custom-block.
	title: __( 'ShortCode Library' ), // Block title.
	icon: 'shortcode', // Block icon from Dashicons → https://developer.wordpress.org/resource/dashicons/.
	category: 'common', // Block category — Group blocks together based on common traits E.g. common, formatting, layout widgets, embed.
	keywords: [
		__( 'shortcode' ),
		__( 'short' ),
		__( 'library' ),
	],

attributes: {
	
	// title: {
	// 	type: 'string',
	// },

	catSelect: {
		type: 'string',
	},


},

edit: (props) => { 
	
	const { attributes, setAttributes , selectedPost , onChangePost } = props;
	
	
	return ([
		<div>
			{ /* <InspectorControls>
				<PanelBody
					title="Settings"
					initialOpen={true}
				>
					<PanelRow className={ props.className }>
						<h3>Title</h3>,
							<RichText
								tagName="p"
								value={ attributes.title }
								onChange={ (newval) => setAttributes({ title: newval }) }
								placeholder={ __( 'Add Subscription form title' ) }
							/>
					</PanelRow>
					<PanelRow>
					<h3>Category</h3>,
							<SelectControl
									
									value={ attributes.catSelect }
									options={ postSelections }
									onChange={(newval) => setAttributes({ catSelect: newval })}
							/>
					</PanelRow>
					<PanelRow>
					<h3>Seltect Template</h3>,
							<SelectControl
									
									value={ attributes.TemplateView }
									options={ [
										{ value: 'grid-view', label: 'Grid View' },
										{ value: 'list-view', label: 'List View' },
									]  }
									onChange={(newval) => setAttributes({ TemplateView: newval })}
							/>
					</PanelRow>
				
					<PanelRow className={ props.className }>
						<h3>Events To Display</h3>,
							<RichText
								tagName="p"
								value={ attributes.eventNumber }
								onChange={ (newval) => setAttributes({ eventNumber: newval }) }
								placeholder={ __( 'add 1 to 10 in numbers' ) }
							/>
					</PanelRow>
					<PanelRow className={ props.className }>
						<h3>Button Text</h3>,
							<RichText
								tagName="p"
								value={ attributes.buttonText }
								onChange={ (newval) => setAttributes({ buttonText: newval }) }
								placeholder={ __( 'Button text to display' ) }
							/>
					</PanelRow>
				</PanelBody>
			 </InspectorControls>  */}

			
				</div>,
				<div className={ props.className }>
							<div class="event-card-main">
								<div class="panel">
									<h5>Select Shortcode: </h5>
									<div>
									<SelectControl
										value={ attributes.catSelect }
										options={ postSelections }
										onChange={(newval) => setAttributes({ catSelect: newval })}
									/>
								</div>
								</div>	
							</div>
				</div>,
				// showCustomer()
								]);
	},
save: function( props ){
	return null;
  },
});