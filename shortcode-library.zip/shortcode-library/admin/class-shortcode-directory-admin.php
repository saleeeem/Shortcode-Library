<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       def.com
 * @since      1.0.0
 *
 * @package    Shortcode_Directory
 * @subpackage Shortcode_Directory/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Shortcode_Directory
 * @subpackage Shortcode_Directory/admin
 * @author     wpminds <wpminds@gmail.com>
 */
class Shortcode_Directory_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Shortcode_Directory_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Shortcode_Directory_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/shortcode-directory-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Shortcode_Directory_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Shortcode_Directory_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/shortcode-directory-admin.js', array( 'jquery' ), $this->version, false );

	}

	//register the settings page for shortcode
	function shortcode_directory_settings_page(){
		add_menu_page( 'Shortcode Library', 'shortcode library', 'manage_options', 'shortcode-library', array($this ,'shortcode_library_page_callback'), 'dashicons-editor-justify',22 );
	}


	//callback funtion for the settings page
	function shortcode_library_page_callback(){
		require_once plugin_dir_path(__FILE__).'partials/settings-page-callback.php';
	}
	function shortcode_delete(){
		global $wpdb; // this is how you get access to the database
		$table_name = $wpdb->prefix . 'shortcode_directory_table';
		$whatever = intval( $_POST['id'] );
		$id = $_POST['id'];
		$wpdb->delete( $table_name, array( 'id' => $id ) );
		echo $id;

	wp_die(); // this is required to terminate immediately and return a proper response
	}


	

	
}
